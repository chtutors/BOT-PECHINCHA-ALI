import os, time, random, string
from selenium import webdriver


class Bot:
    def __init__(self, linkPechincha, proxyList, deviceList, tempoDeEspera, useProxy, useDevice):
        self.chrome_options = webdriver.ChromeOptions()
        self.service_args = []
        self.linkPechincha = linkPechincha
        self.proxyList = proxyList
        self.selectedProxy = None
        self.useProxy = useProxy
        if self.useProxy:
            self.selectedProxy = random.choice(self.proxyList)
            self.service_args = ["--proxy=http://%s" % self.selectedProxy, '--ignore-ssl-errors=yes']
            self.chrome_options.add_argument("--proxy-server=http://%s" % self.selectedProxy)
        self.deviceList = deviceList
        self.selectedDevice = "Nexus 5"
        self.useDevice = useDevice
        if self.useDevice:
            self.selectedDevice = random.choice(self.deviceList)
        self.mobileEmulation = {"deviceName": self.selectedDevice}
        self.chrome_options.add_experimental_option("mobileEmulation", self.mobileEmulation)
        # self.chrome_options.add_argument("--headless")
        self.chrome_options.add_argument("--no-sandbox")
        self.chrome_options.add_argument("--mute-audio")
        self.chrome_options.add_argument("--log-level=3")
        self.chrome_options.add_argument("--ignore-certificate-errors")
        self.chrome_options.add_argument('--disable-gpu')
        self.chrome_options.add_argument('--disable-extensions')
        self.chrome_options.add_argument('--disable-default-apps')
        self.chrome_options.add_argument("--disable-dev-shm-usage")
        self.tempoDeEspera = tempoDeEspera
        self.driver = webdriver.Chrome(options=self.chrome_options, service_args=self.service_args)
        self.driver.implicitly_wait(self.tempoDeEspera)
        self.randDigits = 13
        self.randemail = ("".join(random.choices(string.ascii_uppercase + string.digits, k=self.randDigits))) + "@gmail.com"
        self.randpass = "".join(random.choices(string.ascii_uppercase + string.digits, k=self.randDigits))
        self.Ajudinha()

    def Ajudinha(self):
        self.driver.get(self.linkPechincha)
        self.driver.find_element_by_xpath("/html/body/div/div/div[2]/div[4]/div/a").click()
        self.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[1]/div/ul/li[1]").click()
        self.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div/div/div/div[4]/div[1]/input").send_keys(self.randemail)
        self.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div/div/div/div[4]/div[2]/input").send_keys(self.randpass)
        self.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div/div/div/div[4]/div[5]/a").click()
        time.sleep(5)
        self.driver.find_element_by_xpath("/html/body/header/span/i").click()
        self.driver.find_element_by_xpath("/html/body/div/div/div[2]/div[4]/div/a").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("/html/body/div[3]/div/div[2]/div/div/div/span").click()
        resultado = float(self.driver.find_element_by_xpath("/html/body/div/div/div[2]/div[3]/div[3]/div[1]/div[3]/div/div/div/div[2]/div/div/div").get_attribute("innerHTML").replace("%", ""))
        self.driver.close()
        print(resultado)
