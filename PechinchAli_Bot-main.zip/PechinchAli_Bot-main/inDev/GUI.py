import multiprocessing
import threading
from multiprocessing import freeze_support

from PyQt5 import QtCore, QtGui, QtWidgets
import ajudinhaSelenium


class Aviso(QtWidgets.QDialog):
    def __init__(self, status, parent=None):
        super().__init__(parent=parent)
        self.buttonBox = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.accepted.connect(self.accept)
        self.layout = QtWidgets.QVBoxLayout()
        Aviso.setWindowIcon(self, QtGui.QIcon("Assets/zor.png"))
        Aviso.setWindowTitle(self, "Aviso!")
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        message = QtWidgets.QLabel("Você deve selecionar um arquivo .txt!")
        if status == 1:
            message.setText("Arquivo carregado com sucesso!")
        message.setFont(font)
        self.layout.addWidget(message)
        self.layout.addWidget(self.buttonBox)
        self.setLayout(self.layout)


class Ui_MainWindow(object):
    proxyList = []
    deviceList = []
    processes = []

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(452, 322)
        # Icon Source: https://www.deviantart.com/thecriticalkidd/art/SSBU-Misc-Zeraora-s-Stock-Icon-754020106
        MainWindow.setWindowIcon(QtGui.QIcon("Assets/zor.png"))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(0, -10, 451, 311))
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.txtLink = QtWidgets.QLabel(self.groupBox)
        self.txtLink.setGeometry(QtCore.QRect(10, 20, 181, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.txtLink.setFont(font)
        self.txtLink.setObjectName("txtLink")
        self.txtLinkPechincha = QtWidgets.QLineEdit(self.groupBox)
        self.txtLinkPechincha.setGeometry(QtCore.QRect(200, 20, 241, 22))
        self.txtLinkPechincha.setObjectName("txtLinkPechincha")
        self.label = QtWidgets.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(10, 50, 201, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.qntAjudas = QtWidgets.QSpinBox(self.groupBox)
        self.qntAjudas.setGeometry(QtCore.QRect(220, 50, 42, 22))
        self.qntAjudas.setMinimum(1)
        self.qntAjudas.setMaximum(20)
        self.qntAjudas.setObjectName("qntAjudas")
        self.label_2 = QtWidgets.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(10, 80, 161, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(10, 110, 211, 31))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.btnProxyList = QtWidgets.QPushButton(self.groupBox)
        self.btnProxyList.setGeometry(QtCore.QRect(170, 80, 93, 28))
        self.btnProxyList.setObjectName("btnProxyList")
        self.ckProxy = QtWidgets.QCheckBox(self.groupBox)
        self.ckProxy.setGeometry(QtCore.QRect(270, 80, 131, 20))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.ckProxy.setFont(font)
        self.ckProxy.setObjectName("ckProxy")
        self.btnDeviceList = QtWidgets.QPushButton(self.groupBox)
        self.btnDeviceList.setGeometry(QtCore.QRect(230, 110, 93, 28))
        self.btnDeviceList.setObjectName("btnDeviceList")
        self.ckDevices = QtWidgets.QCheckBox(self.groupBox)
        self.ckDevices.setGeometry(QtCore.QRect(330, 110, 91, 20))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.ckDevices.setFont(font)
        self.ckDevices.setObjectName("ckDevices")
        self.btnInfo = QtWidgets.QPushButton(self.groupBox)
        self.btnInfo.setGeometry(QtCore.QRect(10, 240, 93, 28))
        self.btnInfo.setObjectName("btnInfo")
        self.btnKill = QtWidgets.QPushButton(self.groupBox)
        self.btnKill.setGeometry(QtCore.QRect(330, 240, 93, 28))
        self.btnKill.setObjectName("btnKill")
        self.btnStart = QtWidgets.QPushButton(self.groupBox)
        self.btnStart.setGeometry(QtCore.QRect(170, 240, 93, 28))
        self.btnStart.setObjectName("btnStart")
        self.progressoAjudas = QtWidgets.QProgressBar(self.groupBox)
        self.progressoAjudas.setGeometry(QtCore.QRect(10, 280, 441, 23))
        self.progressoAjudas.setProperty("value", 0)
        self.progressoAjudas.setObjectName("progressoAjudas")
        self.cbEspera = QtWidgets.QDoubleSpinBox(self.groupBox)
        self.cbEspera.setGeometry(QtCore.QRect(280, 180, 62, 22))
        self.cbEspera.setSuffix("")
        self.cbEspera.setMinimum(45.0)
        self.cbEspera.setObjectName("cbEspera")
        self.label_4 = QtWidgets.QLabel(self.groupBox)
        self.label_4.setGeometry(QtCore.QRect(10, 150, 131, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.groupBox)
        self.label_5.setGeometry(QtCore.QRect(10, 180, 271, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "PechinchAli_Bot"))
        self.txtLink.setText(_translate("MainWindow", "Link da Pechincha:"))
        self.txtLinkPechincha.setPlaceholderText(_translate("MainWindow", "https://a.aliexpress.com/_mqMVDkt"))
        self.label.setText(_translate("MainWindow", "Ajudas Simultâneas:"))
        self.qntAjudas.setToolTip(_translate("MainWindow", "Recomendado pelo menos 150 proxies adicionados por instância"))
        self.label_2.setText(_translate("MainWindow", "Lista de Proxy:"))
        self.label_3.setText(_translate("MainWindow", "Lista de Dispositivos:"))
        self.btnProxyList.setText(_translate("MainWindow", "Selecionar..."))
        self.ckProxy.setText(_translate("MainWindow", "NÃO usar proxy!"))
        self.btnDeviceList.setText(_translate("MainWindow", "Selecionar..."))
        self.ckDevices.setText(_translate("MainWindow", "Não usar!"))
        self.btnInfo.setText(_translate("MainWindow", "Info"))
        self.btnKill.setText(_translate("MainWindow", "Parar!"))
        self.btnStart.setText(_translate("MainWindow", "Iniciar!"))
        self.label_4.setText(_translate("MainWindow", "(OPCIONAL)"))
        self.label_5.setText(_translate("MainWindow", "Tempo de espera (em segundos):"))
        self.btnProxyList.clicked.connect(self.EscolheProxy)
        self.btnInfo.clicked.connect(self.Info)
        self.btnDeviceList.clicked.connect(self.EscolheDispositivo)
        self.btnKill.clicked.connect(self.Kill)
        self.btnStart.clicked.connect(self.Iniciar)

    def Iniciar(self):
        linkPechincha = self.txtLinkPechincha.text()
        threadHelp = self.qntAjudas.value()
        proxyList = self.proxyList
        deviceList = self.deviceList
        tempoDeEspera = self.cbEspera.value()
        useProxy = False
        useDevice = False
        argsx = (linkPechincha, proxyList, deviceList, tempoDeEspera, useProxy, useDevice)
        print('começando drivers')
        try:
            # freeze_support()
            self.processes = []
            for i in range(threadHelp):
                p = multiprocessing.Process(target=ajudinhaSelenium.Bot, args=argsx)
                self.processes.append(p)
                p.start()
            for p in self.processes:
                p.join()
        except Exception as e:
            print(e)

    def Kill(self):
        self.processes.clear()

    def CarregarLista(self, tipo):
        listaDeDados = []
        arquivoSelecionado = QtWidgets.QFileDialog.getOpenFileName()
        if not arquivoSelecionado[0].endswith('.txt'):
            Aviso(666).exec_()
            return
        else:
            if tipo == 1:
                with open(arquivoSelecionado[0], 'r') as arquivo:
                    for line in arquivo:
                        if ":" not in line:
                            continue
                        else:
                            listaDeDados.append(line.strip())
                Aviso(1).exec_()
            elif tipo == 2:
                with open(arquivoSelecionado[0], 'r') as arquivo:
                    for line in arquivo:
                        if line is None:
                            continue
                        else:
                            listaDeDados.append(line.strip())
                Aviso(1).exec_()
        return listaDeDados

    def EscolheProxy(self):
        self.btnProxyList.setText("Selecionar...")
        Ui_MainWindow.proxyList.clear()
        Ui_MainWindow.proxyList = self.CarregarLista(1)
        if Ui_MainWindow.proxyList is not None:
            self.btnProxyList.setText(str(len(Ui_MainWindow.proxyList))+" Carregados!")

    def EscolheDispositivo(self):
        self.btnDeviceList.setText("Selecionar...")
        Ui_MainWindow.deviceList.clear()
        Ui_MainWindow.deviceList = self.CarregarLista(2)
        if Ui_MainWindow.proxyList is not None:
            self.btnDeviceList.setText(str(len(Ui_MainWindow.deviceList)) + " Carregados!")

    def Info(self):
        print('info')


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
